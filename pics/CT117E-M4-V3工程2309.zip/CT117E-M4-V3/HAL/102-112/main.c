/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "lcd.h"
#include "stdio.h"
#include "i2c.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
uint8_t ucKey;    		        			/* ����ֵ */
uint8_t ucLed;        	      			/* LEDֵ */
uint8_t ucLcd[21];                 	/* LCDֵ(\0����) */
uint16_t usTlcd;      	      			/* LCDˢ��ʱ�� */
uint8_t ucState;		          			/* ����״̬ */
uint8_t ucMode;			          			/* ģʽ״̬ */
uint16_t usAdc;				          		/* ADCת��ֵ */
uint8_t ucTtim;     		      			/* TIMˢ��ʱ�� */
uint16_t usComp;				          	/* PA6��PA7�Ƚ�ֵ */
uint16_t usComp6=1000;		      		/* PA6�Ƚ�ֵ */
uint16_t usComp7=500;		        		/* PA7�Ƚ�ֵ */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void KEY_Proc(void);              	/* �������� */
void LED_Proc(void);              	/* LED���� */
void LCD_Proc(void);              	/* LCD���� */
void TIM_Proc(void);              	/* TIM���� */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
//  MX_ADC1_Init();
  MX_ADC2_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
//  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */
  LCD_Init();                      	/* LCD��ʼ�� */
  LCD_Clear(Black);                	/* LCD���� */
  LCD_SetTextColor(White);        	/* �����ַ�ɫ */
  LCD_SetBackColor(Black);        	/* ���ñ���ɫ */
	
  TIM3_SetAutoReload(9999);		    	/* �޸�PA6Ƶ��Ϊ100Hz */
  TIM1_SetAutoReload(4999);	    		/* �޸�PA7Ƶ��Ϊ200Hz */
  TIM3_SetCompare1(1000);		       	/* �޸�PA6ռ�ձ�Ϊ10% */
  TIM1_SetCompare1(500);	   	    	/* �޸�PA7ռ�ձ�Ϊ10% */
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    KEY_Proc();                    	/* �������� */
    LED_Proc();                    	/* LED���� */
    LCD_Proc();                    	/* LCD���� */
    TIM_Proc();    	        				/* TIM���� */
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/* USER CODE BEGIN 4 */
void KEY_Proc(void)               	/* �������� */
{
  uint8_t ucKey_Val = 0;

  ucKey_Val = KEY_Read();         	/* ������ȡ */
  if (ucKey_Val != ucKey)         	/* ��ֵ�仯 */
    ucKey = ucKey_Val;            	/* �����ֵ */
  else
    ucKey_Val = 0;                 	/* �����ֵ */

  switch (ucKey_Val)
  {
    case 1:                        	/* B1������ */
      ucState ^= 1;             		/* �л�״̬ */
      ucLed ^= 2;                 	/* �л�LD2 */
      LCD_Clear(Black); 	     			/* LCD���� */
      break;
    case 2:                        	/* B2������ */
      if (ucState == 1)	      			/* �������� */
      {
        usComp6 += 1000;
        if(usComp6 == 10000)
          usComp6 = 1000;
      }
      break;
    case 3:                        	/* B3������ */
      if (ucState == 1)	      			/* �������� */
      {
        usComp7 += 500;
        if (usComp7 == 5000)
          usComp7 = 500;
      }
      break;
    case 4:                        	/* B4������ */
      ucMode ^= 1;                 	/* �л�ģʽ״̬ */
      ucLed ^= 1;  	               	/* �л�LD1 */
  }
}

void LED_Proc(void)               	/* LED���� */
{
  LED_Disp(ucLed);                 	/* LED��ʾ */
}

void LCD_Proc(void)               	/* LCD���� */
{
  uint16_t usCapt[2];

  if (usTlcd < 100)   			       	/* 100msδ�� */
    return;
  usTlcd = 0;

  if (ucState == 0)  	        			/* ���ݽ��� */
  {
    sprintf((char*)ucLcd, "      Data");
    LCD_DisplayStringLine(Line0, ucLcd);

    sprintf((char *)ucLcd, "    V:%4.2fV", usAdc*3.3/4095);
    LCD_DisplayStringLine(Line2, ucLcd);
    if (ucMode == 0)
      sprintf((char *)ucLcd, "    Mode:AUTO");
    else
      sprintf((char *)ucLcd, "    Mode:MANU");
    LCD_DisplayStringLine(Line4, ucLcd);
  } else { 				            			/* �������� */
    sprintf((char*)ucLcd, "      Para");
    LCD_DisplayStringLine(Line0, ucLcd);

    sprintf((char *)ucLcd, "    PA6:%2u%%", usComp6/100);
    LCD_DisplayStringLine(Line2, ucLcd);
    sprintf((char *)ucLcd, "    PA7:%2u%%", usComp7/50);
    LCD_DisplayStringLine(Line4, ucLcd);
  }
  TIM2_GetCapture(usCapt);		    	/* ������ */
  sprintf((char *)ucLcd, "    Duty:%02u%%", usCapt[0]*100/usCapt[1]);
  LCD_DisplayStringLine(Line6, ucLcd);
}

void TIM_Proc(void)               	/* TIM���� */
{
  if (ucTtim < 100)   	      			/* 100msδ�� */
    return;
  ucTtim = 0;

  if (ucMode == 0)
  {
    usAdc = ADC2_Read();
    usComp = usAdc * 10000 / 4095;
    TIM3_SetCompare1(usComp);	    	/* �޸�PA6ռ�ձ� */
    TIM1_SetCompare1(usComp>>1);  	/* �޸�PA7ռ�ձ� */
  } else {
    TIM3_SetCompare1(usComp6);  		/* �޸�PA6ռ�ձ� */
    TIM1_SetCompare1(usComp7);	  	/* �޸�PA7ռ�ձ� */
  }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
