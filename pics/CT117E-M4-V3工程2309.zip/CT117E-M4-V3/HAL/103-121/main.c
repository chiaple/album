/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"
#include "string.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "lcd.h"
#include "stdio.h"
#include "i2c.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef struct
{
  char    cType[5];            		/* ��������(\0����) */
  char    cNo[5];              		/* �������(\0����) */
  uint8_t ucYear;             		/* �� */
  uint8_t ucMonth;             		/* �� */
  uint8_t ucDay;               		/* �� */
  uint8_t ucHour;              		/* ʱ */
  uint8_t ucMinute;            		/* �� */
  uint8_t ucSecond;            		/* �� */	
} sCinfo;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
uint8_t ucState;   		        			/* ϵͳ״̬ */
uint8_t ucKey;      		      			/* ����ֵ */
uint8_t ucLed;   	          				/* LEDֵ */
uint8_t ucLcd[21];                 	/* LCDֵ(\0����) */
uint16_t usTlcd;      	      			/* LCDˢ��ʱ�� */
uint8_t ucUrx[23];                 	/* UART����ֵ(\0����) */
uint8_t ucNcnbr=0;              		/* CNBR���� */
uint8_t ucNvnbr=0;              		/* VNBR���� */
uint8_t ucNidle=8;               		/* IDLE���� */
uint8_t ucFcnbr=35;              		/* CNBR����(*10) */
uint8_t ucFvnbr=20;             		/* VNBR����(*10) */
uint8_t ucLocation;                	/* λ�� */
uint16_t usHours;                  	/* ʱ�� */
uint16_t usMoney;                  	/* ���� */
sCinfo sNew;                       	/* �½��ճ�����Ϣ */
sCinfo sCar[8];                    	/* ͣ����������Ϣ */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void KEY_Proc(void);              	/* �������� */
void LED_Proc(void);              	/* LED���� */
void LCD_Proc(void);              	/* LCD���� */
void UART_Proc(void);              	/* UART���� */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
//  MX_ADC1_Init();
//  MX_ADC2_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
//  MX_TIM3_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */
  LCD_Init();                      	/* LCD��ʼ�� */
  LCD_Clear(Black);                	/* LCD���� */
  LCD_SetTextColor(White);        	/* �����ַ�ɫ */
  LCD_SetBackColor(Black);        	/* ���ñ���ɫ */
	
  TIM1_SetCompare1(0);		          /* �޸�PA7ռ�ձ�Ϊ0% */
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    KEY_Proc();                    	/* �������� */
    LED_Proc();                    	/* LED���� */
    LCD_Proc();                    	/* LCD���� */
    UART_Proc();    		      			/* UART���� */
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/* USER CODE BEGIN 4 */
void KEY_Proc(void)               	/* �������� */
{
  uint8_t ucKey_Val = 0;

  ucKey_Val = KEY_Read();         	/* ������ȡ */
  if (ucKey_Val != ucKey)         	/* ��ֵ�仯 */
    ucKey = ucKey_Val;            	/* �����ֵ */
  else
    ucKey_Val = 0;                 	/* �����ֵ */

  switch (ucKey_Val)
  {
    case 1:                         /* B1������ */
      ucState ^= 1;                 /* �л�״̬ */
      LCD_Clear(Black);           	/* LCD���� */
      break;
    case 2:                         /* B2������ */
      if (ucState == 1)             /* �������� */
      {
        ucFcnbr += 5;
        ucFvnbr += 5;
      }
      break;
    case 3:                         /* B3������ */
      if (ucState == 1)             /* �������� */
      {
        if (ucFvnbr > 5)
        {
          ucFcnbr -= 5;
          ucFvnbr -= 5;
        }
      }
      break;
    case 4:                         /* B4������ */
      ucLed ^= 2;                   /* �л�LD2 */
      if ((ucLed & 2) == 2)
        TIM1_SetCompare1(100);      /* �޸�PA7ռ�ձ�Ϊ20% */
      else
        TIM1_SetCompare1(0);        /* �޸�PA7ռ�ձ�Ϊ0% */
  }
}

void LED_Proc(void)               	/* LED���� */
{
  if (ucNidle != 0)
    ucLed |= 1;                     /* ����LD1 */
  else
    ucLed &= ~1;                    /* Ϩ��LD1 */
  LED_Disp(ucLed);                 	/* LED��ʾ */
}

void LCD_Proc(void)               	/* LCD���� */
{
  uint16_t usCapt[2];

  if (usTlcd < 500)                	/* 500msδ�� */
    return;
  usTlcd = 0;

  if (ucState == 0)		        			/* ���ݽ��� */
  {
    sprintf((char*)ucLcd, "       Data");
    LCD_DisplayStringLine(Line1, ucLcd);
    sprintf((char *)ucLcd, "   CNBR:%1u", ucNcnbr);
    LCD_DisplayStringLine(Line3, ucLcd);
    sprintf((char *)ucLcd, "   VNBR:%1u", ucNvnbr);
    LCD_DisplayStringLine(Line5, ucLcd);
    sprintf((char *)ucLcd, "   IDLE:%1u", ucNidle);
    LCD_DisplayStringLine(Line7, ucLcd);
  } else {                          /* �������� */
    sprintf((char*)ucLcd, "       Para");
    LCD_DisplayStringLine(Line1, ucLcd);
    sprintf((char *)ucLcd, "   CNBR:%3.2f", ucFcnbr/10.0);
    LCD_DisplayStringLine(Line3, ucLcd);
    sprintf((char *)ucLcd, "   VNBR:%3.2f", ucFvnbr/10.0);
    LCD_DisplayStringLine(Line5, ucLcd);
    if ((ucLed & 2) == 2)
      TIM2_GetCapture(usCapt);		  /* ������ */
    else
      usCapt[1] = 0;
    sprintf((char *)ucLcd, "   DUTY:%02u%%  ", usCapt[0]*100/usCapt[1]);
    LCD_DisplayStringLine(Line7, ucLcd);
  }
}

void UART_Proc(void)              	/* UART���� */
{
  if (UART_Receive(ucUrx, 22) != 0)
    return;
  printf("%s\r\n", ucUrx);
  for (uint8_t i=0; i<4; i++)       /* ��Ϣ���� */
  {
    sNew.cType[i] = ucUrx[i];
    sNew.cNo[i] = ucUrx[i+5];
  }
  sNew.ucYear   = (ucUrx[10]-'0')*10+ucUrx[11]-'0';
  sNew.ucMonth  = (ucUrx[12]-'0')*10+ucUrx[13]-'0';
  sNew.ucDay    = (ucUrx[14]-'0')*10+ucUrx[15]-'0';
  sNew.ucHour   = (ucUrx[16]-'0')*10+ucUrx[17]-'0';
  sNew.ucMinute = (ucUrx[18]-'0')*10+ucUrx[19]-'0';
  sNew.ucSecond = (ucUrx[20]-'0')*10+ucUrx[21]-'0';

  if (((strcmp(sNew.cType, "CNBR")==0) || strcmp(sNew.cType, "VNBR")==0)
    && sNew.ucYear<=99 && sNew.ucMonth<=12 && sNew.ucDay<=30
    && sNew.ucHour<=23 && sNew.ucMinute<60 && sNew.ucSecond<60)
  {
    for (uint8_t i=0; i<8; i++) 	  /* ���볡�ж� */
    {
      if (sCar[i].cType[0]==0) 
        ucLocation = i;             /* �ճ�λ */
      if ((strcmp(sNew.cType, sCar[i].cType)==0) &&
        strcmp(sNew.cNo, sCar[i].cNo)==0)
      {
        ucLocation = i+8;           /* ͣ��λ */
        break;
      }
    }
    if (ucLocation<8)               /* �볡���� */
    {
      if (ucNidle != 0)
      {
        strcpy(sCar[ucLocation].cType, sNew.cType);
        strcpy(sCar[ucLocation].cNo, sNew.cNo);
        sCar[ucLocation].ucYear   = sNew.ucYear;
        sCar[ucLocation].ucMonth  = sNew.ucMonth;
        sCar[ucLocation].ucDay    = sNew.ucDay;
        sCar[ucLocation].ucHour   = sNew.ucHour;
        sCar[ucLocation].ucMinute = sNew.ucMinute;
        sCar[ucLocation].ucSecond = sNew.ucSecond;
        if (sNew.cType[0] == 'C')
          ucNcnbr++;
        else
          ucNvnbr++;
        ucNidle--;
      }
    } else {                        /* �������� */
      ucLocation -= 8;             	/* ʱ������ */
      usHours = (((sNew.ucYear-sCar[ucLocation].ucYear)*365+
        (sNew.ucMonth-sCar[ucLocation].ucMonth)*30+
        sNew.ucDay-sCar[ucLocation].ucDay)*24+
        sNew.ucHour-sCar[ucLocation].ucHour);
      if (((sNew.ucMinute-sCar[ucLocation].ucMinute)*60+
        sNew.ucSecond-sCar[ucLocation].ucSecond) > 0)
        usHours++;
      if (sNew.cType[0] == 'C')
      {
        ucNcnbr--;
        usMoney = usHours * ucFcnbr;
      } else {
        ucNvnbr--;
        usMoney = usHours * ucFvnbr;
      }
      ucNidle++;
      printf("%s:%s:%2u:%5.2f\r\n",	sNew.cType, sNew.cNo,
        usHours, usMoney/10.0);
      sCar[ucLocation].cType[0]=0;  /* ɾ��������Ϣ */
    }
  }
  else
    printf("error\r\n");            /* ��ʽ���� */
}

int fputc(int ch, FILE *f)		    	/* printf()ʵ�� */
{
  UART_Transmit((uint8_t *)&ch, 1);
  return ch;
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
