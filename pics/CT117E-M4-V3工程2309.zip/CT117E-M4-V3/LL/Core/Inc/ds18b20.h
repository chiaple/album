#ifndef __DHT11_H__
#define __DHT11_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"

uint16_t DSB_Read(void);

#ifdef __cplusplus
}
#endif

#endif /* __DHT11_H__ */
